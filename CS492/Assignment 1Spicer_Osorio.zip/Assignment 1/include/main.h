#ifndef _MAIN_H_
#define _MAIN_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <pthread.h>
#include <sys/time.h>
#include <limits.h>

#include "product.h"
#include "queue.h"


extern int productCountGLOBAL;
extern int consumerCountGLOBAL;
extern int maxProductsGLOBAL;
extern int schedulingGLOBAL;
extern int quantumGLOBAL;
extern pthread_mutex_t createProductLockGLOBAL;
extern pthread_mutex_t consumeProductLockGLOBAL;
extern long* taArr;
extern long* waitArr;
extern double temp;

int                 main(int argc, char** argv);
struct product*     createProduct();
void*               producer(void*);
void*               consumer(void*);
int                 fib(int);
long int maximum(long*, size_t);
long int minimum(long*, size_t);
long int average(long*, size_t);

#endif