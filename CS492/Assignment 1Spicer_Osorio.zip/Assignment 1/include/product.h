
#ifndef _PRODUCT_H_
#define _PRODUCT_H_

struct product
{

	int id;
	struct timeval time;
	struct timeval time_inserted;
	struct timeval producedAt;
	struct timeval startedConsumptionAt;
	struct timeval consumedAt;
	int life;
	double insertedTemp;
};

#endif