#ifndef _QUEUE_H_
#define _QUEUE_H_

#include "product.h"

void queueInit(int);
void pushQueue(struct product*);
struct product* popQueue();
struct product* tempPop();
void tempPush(struct product*);
void decreaseQueue();

#endif