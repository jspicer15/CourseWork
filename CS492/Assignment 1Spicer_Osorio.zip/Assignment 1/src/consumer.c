/*
John Spicer (jspicer)
Michael Osorio (mosorio2)
02/02/17
I pledge my honor that I have abided by the Stevens Honor System."
*/

#include "main.h"

/*consumer function*/
void* consumer(void *x)
{
	struct product* prod = malloc(sizeof(struct product*));
	int consumer_id = *((int*)x); 
	int i = 0;
	double temp1;
	double temp2;
	double temp3;

	/*products are consumed as long as the count is not equal to the max number of products*/
	while (consumerCountGLOBAL < maxProductsGLOBAL - 1)
	{
		/*locks to prevent problems with the consumers count*/
		pthread_mutex_lock(&consumeProductLockGLOBAL);

		if (consumerCountGLOBAL >= maxProductsGLOBAL)
		{
			/*unlocks*/
			pthread_mutex_unlock(&consumeProductLockGLOBAL);
			return NULL;
		}

		/*unlocks*/
		pthread_mutex_unlock(&consumeProductLockGLOBAL);

		/*first come, first serve*/
		if (schedulingGLOBAL == 0)
		{
			/*pop item*/
			prod = popQueue();
			gettimeofday(&(prod->startedConsumptionAt), NULL);

			if (prod == NULL)
			{
				return NULL;
			}

			while (i <= prod->life)
			{
				fib(10);
				i++;
			}
			/*lock*/
			pthread_mutex_lock(&consumeProductLockGLOBAL);

			gettimeofday(&(prod->consumedAt), NULL);
			/*add elements to taArr and waitArr*/
			taArr[consumerCountGLOBAL] = (prod->consumedAt.tv_sec*1e6 + prod->consumedAt.tv_usec) - (prod->producedAt.tv_sec*1e6 + prod->producedAt.tv_usec);
			waitArr[consumerCountGLOBAL] = (prod->startedConsumptionAt.tv_sec*1e6 + prod->startedConsumptionAt.tv_usec) - (prod->time_inserted.tv_sec*1e6 + prod->time_inserted.tv_usec);
			/*incremenet consumers count*/
			consumerCountGLOBAL++;

			/*unlock*/
			pthread_mutex_unlock(&consumeProductLockGLOBAL);

			printf("Consumer %d has consumed product %d\n", consumer_id, prod->id);
			/*free memory*/
			free(prod);
		}

		/*round robin*/
		else if (schedulingGLOBAL == 1)
		{
			/*pop product using tempPop*/
			prod = tempPop();

			if (prod == NULL)
			{
				return NULL;
			}

			if (prod->startedConsumptionAt.tv_sec == (struct timeval){0}.tv_sec)
			{
				prod->startedConsumptionAt = (struct timeval){0};
				gettimeofday(&(prod->startedConsumptionAt), NULL);
				temp1 = prod->startedConsumptionAt.tv_sec*1e6 + prod->startedConsumptionAt.tv_usec;
			}

			if (prod->life > quantumGLOBAL)
			{
				/*performs a quantum number of fibonacci calculations*/
				while (i < quantumGLOBAL)
				{
					fib(10);
					i++;
				}

				prod->life = prod->life - quantumGLOBAL;
				/*push using tempPush*/
				tempPush(prod);
			}

			else if (prod->life <= quantumGLOBAL)
			{
				while (i < prod->life)
				{
					fib(10);
					i++;
				}
				/*descreases the queue*/
				decreaseQueue();

				pthread_mutex_lock(&consumeProductLockGLOBAL);
				gettimeofday(&(prod->consumedAt), NULL);
				temp1 = prod->startedConsumptionAt.tv_sec*1e6 + prod->startedConsumptionAt.tv_usec;
				temp2 = prod->insertedTemp;
				temp3 = temp1 - temp2;
				/*turnaround time*/
				taArr[consumerCountGLOBAL] = (prod->consumedAt.tv_sec*1e6 + prod->consumedAt.tv_usec) - (prod->producedAt.tv_sec*1e6 + prod->producedAt.tv_usec);
				/*wait time*/
				waitArr[consumerCountGLOBAL] = temp3;
				consumerCountGLOBAL++;
				pthread_mutex_unlock(&consumeProductLockGLOBAL);
				/*experimentation/testing*/
				printf("Consumer %d has consumed product %d\n", consumer_id, prod->id);
				fflush(stdout);
				/*free memory*/
				free(prod);
			}

			
		}
		/*sleeps*/
		usleep(100000);

	}

	return NULL;
}