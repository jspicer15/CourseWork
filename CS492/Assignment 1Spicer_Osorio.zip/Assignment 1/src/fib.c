/*
John Spicer (jspicer)
Michael Osorio (mosorio2)
02/02/17
I pledge my honor that I have abided by the Stevens Honor System."
*/

#include "main.h"

/*the nth fibonnaci number*/
int fib(int n)
{
   if (n <= 1)
   {
      return n;
   }
   else
   {
      return fib(n-1) +fib(n-2);
   }
}