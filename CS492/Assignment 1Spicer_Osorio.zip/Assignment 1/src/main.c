/*
John Spicer (jspicer)
Michael Osorio (mosorio2)
02/02/17
I pledge my honor that I have abided by the Stevens Honor System."
*/

#include "main.h"

int productCountGLOBAL;
int consumerCountGLOBAL;
int maxProductsGLOBAL;
int schedulingGLOBAL;
int quantumGLOBAL;
pthread_mutex_t createProductLockGLOBAL;
pthread_mutex_t consumeProductLockGLOBAL;
long int* taArr;
long int* waitArr;
int temp5;

/*
Main function. Arguments:
P1: number of producers, P2: number of consumers, P3: total number of products
P4: size of the queue, P5: scheduling algorithm, P6: quantum
P7: seed
*/
int main (int argc, char** argv)
{
	int producerCount;
	int consumerCount;
	int queueSize;
	int seed;
	struct timeval begin;
	struct timeval startProducers;
	struct timeval startConsumers;
	struct timeval endProducers;
	struct timeval endConsumers;
	struct timeval end;
	int i = 0;
	long temp1;
	long temp2;
	long tempCount;

	/*check arguments*/
	if (argc != 8)
	{
		printf("Error: Expected 7 arguments", argv[0]);
		return -1;
	}
	else
	{
		productCountGLOBAL = 0;
		consumerCountGLOBAL = 0;
		producerCount = atoi(argv[1]);
		if (producerCount <= 0)
		{
			printf("ERROR: Invalid number of producers");
			return -1;
		}
		consumerCount = atoi(argv[2]);
		if (consumerCount <= 0)
		{
			printf("ERROR: Invalid number of consumers");
			return -1;
		}
		maxProductsGLOBAL = atoi(argv[3]);
		if (maxProductsGLOBAL <= 0)
		{
			printf("ERROR: Invalid number of products");
			return -1;
		}
		queueSize = atoi(argv[4]);
		if (queueSize < 0) 
		{
			printf("ERROR: Invalid queue size");
			return -1;
		}
		schedulingGLOBAL = atoi(argv[5]);
		if ((schedulingGLOBAL != 0) && (schedulingGLOBAL != 1))
		{
			printf("ERROR: Invalid value for scheduling algo");
			return -1;
		}
		quantumGLOBAL = atoi(argv[6]);
		if (quantumGLOBAL <= 0)
		{
			printf("ERROR: Invalid value for quantum. If not using Round Robin, please enter any positive integer");
			return -1;
		}
		seed = atoi(argv[7]);

		/*initialize size of arrays*/
		taArr = malloc(sizeof(long int)*maxProductsGLOBAL);
		waitArr = malloc(sizeof(long int)*maxProductsGLOBAL);

		/*initialize queue*/
		if (queueSize > 0)
		{
			queueInit(queueSize);
		}

		else 
		{
			queueInit(maxProductsGLOBAL);
		}

		/*create pthreads*/
		pthread_t producers[producerCount];
		int prods[producerCount];
		pthread_t consumers[consumerCount];
		int cons[consumerCount];

		pthread_mutex_init(&createProductLockGLOBAL, NULL);
		pthread_mutex_init(&consumeProductLockGLOBAL, NULL);

		/*get the random number for the life*/
		 srandom(seed);

		//START//
		gettimeofday(&begin, NULL);

		//Start Producers//
		gettimeofday(&startProducers, NULL);
		while (i < producerCount)
		{
			prods[i] = i + 1;
			pthread_create(&producers[i], NULL, &producer, (void*) &prods[i]);
			i++;
		}

		i = 0;
		/*start consumers*/
		gettimeofday(&startConsumers, NULL);

		while (i < consumerCount)
		{
			cons[i] = i + 1;
			pthread_create(&consumers[i], NULL, &consumer, (void*) &cons[i]);
			i++;
		}

		i = 0;
		while (i < producerCount)
		{
			pthread_join(producers[i], NULL);
			i++;
		}

		/*end producers*/
		gettimeofday(&endProducers, NULL);

		i = 0;
		while (i < consumerCount)
		{
			pthread_join(consumers[i], NULL);
			i++;
		}

		/*end consumers*/
		gettimeofday(&endConsumers, NULL);
		gettimeofday(&end, NULL);
		/*END*/
		printf("Total time: %lu microseconds\n", (end.tv_sec*1e6 + end.tv_usec) - (begin.tv_sec*1e6 + begin.tv_usec));
		tempCount = productCountGLOBAL;
		temp1 = (endProducers.tv_sec*1e6 + endProducers.tv_usec) - (startProducers.tv_sec*1e6 + startProducers.tv_usec);
		temp2 = (endConsumers.tv_sec*1e6 + endConsumers.tv_usec) - (startConsumers.tv_sec*1e6 + startConsumers.tv_usec);
		/*producer throughput*/
		printf("Producer throughput: %lu items \n", (tempCount * 60000000/(temp1)));
		/*consumer throughput*/
		printf("Consumer throughput: %lu items \n", (tempCount * 60000000/(temp2)));
		/*turnaround times*/
		printf("Turnaround times-\n Max: %ld microseconds\n Min: %ld microseconds\n Average: %ld microseconds\n", maximum(taArr, sizeof(taArr)), minimum(taArr, sizeof(taArr)), average(taArr, sizeof(taArr)));
		/*wait times*/
		printf("Wait times-\n Max: %ld microseconds\n Min: %ld microseconds\n Average: %ld microseconds\n", maximum(waitArr, sizeof(waitArr)), minimum(waitArr, sizeof(waitArr)), average(waitArr, sizeof(waitArr)));
	}
	return 0;
}