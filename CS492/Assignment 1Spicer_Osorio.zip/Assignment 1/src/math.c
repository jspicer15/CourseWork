/*
John Spicer (jspicer)
Michael Osorio (mosorio2)
02/02/17
I pledge my honor that I have abided by the Stevens Honor System."
*/

#include "main.h"

/*gets max value from an array*/
long int maximum(long* arr, size_t size)
{
	int i = 0;
	long max = arr[i];
	while (i != (size))
	{
		if (arr[i] > max)
		{
			max = arr[i];
		}
		i++;
	}
	return max;
}

/*gets min value from an array*/
long int minimum(long* arr, size_t size)
{
	int i = 0;
	long min = arr[i];
	while (i != size)
	{
		if (arr[i] < min)
		{
			min = arr[i];
		}
		i++;
	}
	return min;
}

/*gets average of every item in an array*/
long int average(long* arr, size_t size)
{
	int i = 0;
	long sum = 0;
	long mean;
	while (i != size)
	{
		sum = sum + arr[i];
		i++;
	}
	mean = sum/size;
	return mean;
}