/*
John Spicer (jspicer)
Michael Osorio (mosorio2)
02/02/17
I pledge my honor that I have abided by the Stevens Honor System."
*/

#include "main.h"

double temp = 0;

/*producer function*/
void* producer(void *i)
{
	struct product* prod;
	int producer_id = *((int*)i);
	/*creates products as long as the number of products is less than the max number allowed*/
	while (productCountGLOBAL < maxProductsGLOBAL) 
	{
		/*locks to prevent a problem with the products count*/
		pthread_mutex_lock(&createProductLockGLOBAL);

		/*checks product count*/
		if (productCountGLOBAL >= maxProductsGLOBAL)
		{
			/*unlocks*/
			pthread_mutex_unlock(&createProductLockGLOBAL);
			break;
		}

		prod = createProduct();
		gettimeofday(&(prod->producedAt), NULL);
		pthread_mutex_unlock(&createProductLockGLOBAL);			
		pushQueue(prod);
		gettimeofday(&(prod->time_inserted), NULL);
		prod->insertedTemp = prod->time_inserted.tv_sec*1e6 + prod->time_inserted.tv_usec;
		/*experimentation/testing*/
		printf("Producer %d has produced product %d\n", producer_id, prod->id);
		fflush(stdout);
		/*sleeps*/
		usleep(100000);
	}

	return NULL;
}