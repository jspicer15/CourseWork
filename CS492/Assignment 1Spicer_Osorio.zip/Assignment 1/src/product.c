/*
John Spicer (jspicer)
Michael Osorio (mosorio2)
02/02/17
I pledge my honor that I have abided by the Stevens Honor System."
*/

#include "main.h"

/*creates the products*/
struct product* createProduct()
{
	struct product* prod = (struct product*)malloc(sizeof(struct product));

	/*product being made*/
	if (prod != NULL)
	{
		prod->id = ++productCountGLOBAL;
		gettimeofday(&(prod->time), NULL);
		prod->life = random() % 1024;
		prod->startedConsumptionAt = (struct timeval){0};
	}

	return prod;
}