/*
John Spicer (jspicer)
Michael Osorio (mosorio2)
02/02/17
I pledge my honor that I have abided by the Stevens Honor System."
*/

#include "main.h"


/*Queue struct*/
struct enterQueue {
    struct product *p;
    struct enterQueue *next;
};

/*locks queue from unwanted access*/
static pthread_mutex_t queueLock;
 /*Shows when the queue is full*/
static pthread_cond_t queueIsFull;
 /*Shows when the queue is empty*/
static pthread_cond_t queueIsEmpty;
/*Max size of the queue*/
static int queueMaxSize;
/*current number of itmes in the queue, accounting for temporary spaces*/
static int tempCount; 
 /*Current number of items in the queue*/
static int count;
 /*Queue struct*/
static struct enterQueue *theQueue;

/*initializes the queue*/
void queueInit(int size)
{
    pthread_mutex_init(&queueLock, NULL);
    pthread_cond_init(&queueIsFull, NULL);
    pthread_cond_init(&queueIsEmpty, NULL);
    queueMaxSize = size;
    tempCount = 0;
    count = 0;
    theQueue = NULL;
}

/*pushes a product onto the queue*/
void pushQueue(struct product* prod)
{
    struct enterQueue *newItem;
    struct enterQueue *temp;

    newItem = malloc(sizeof(struct enterQueue));
    if (prod == NULL || newItem == NULL)
        return;

    newItem->p = prod;
    newItem->next = NULL;
    pthread_mutex_lock(&queueLock);
    while (tempCount == queueMaxSize)
        pthread_cond_wait(&queueIsFull, &queueLock);

    if (theQueue == NULL)
        theQueue = newItem;
    else
    {
        temp = theQueue;
        while (temp->next != NULL)
            temp = temp->next;
        temp->next = newItem;
    }
    gettimeofday(&(newItem->p->time_inserted), NULL);
    if (tempCount++ == 0)
        pthread_cond_broadcast(&queueIsEmpty);
    ++count;
    pthread_mutex_unlock(&queueLock);
}

/*pops a product from the queue*/
struct product* popQueue()
{
    struct product *removed = NULL;
    struct enterQueue *temp;

    pthread_mutex_lock(&queueLock);
    while (count == 0)
        pthread_cond_wait(&queueIsEmpty, &queueLock);

    if (theQueue != NULL)
    {
        temp = theQueue;
        removed = temp->p;
        theQueue = temp->next;

        free(temp);

        if (tempCount-- == queueMaxSize)
            pthread_cond_broadcast(&queueIsFull);
        --count;
    }
    pthread_mutex_unlock(&queueLock);

    return removed;
}

/*pops from the queue without decrementing the size of the queue*/
struct product* tempPop()
{
    struct product *removed = NULL;
    struct enterQueue *temp;

    pthread_mutex_lock(&queueLock);
    while (count == 0)
        pthread_cond_wait(&queueIsEmpty, &queueLock);

    if (theQueue != NULL)
    {
        temp = theQueue;
        removed = temp->p;
        theQueue = temp->next;

        free(temp);

        --count;
    }
    pthread_mutex_unlock(&queueLock);

    return removed;
}

/*pushes onto the queue without incrementing the size of the queue*/
void tempPush(struct product* prod)
{
    struct enterQueue *newItem;
    struct enterQueue *temp;

    newItem = malloc(sizeof(struct enterQueue));
    if (prod == NULL || newItem == NULL)
        return;

    newItem->p = prod;
    newItem->next = NULL;

    pthread_mutex_lock(&queueLock);
    if (theQueue == NULL)
        theQueue = newItem;
    else
    {
        temp = theQueue;
        while (temp->next != NULL)
            temp = temp->next;
        temp->next = newItem;
    }
    gettimeofday(&(newItem->p->time_inserted), NULL);
    if (count++ == 0)
        pthread_cond_broadcast(&queueIsEmpty);
    pthread_mutex_unlock(&queueLock);
}

/*decrements the size of the queue*/
void decreaseQueue()
{
    pthread_mutex_lock(&queueLock);
    if (tempCount-- == queueMaxSize)
        pthread_cond_broadcast(&queueIsFull);
    pthread_mutex_unlock(&queueLock);
}
