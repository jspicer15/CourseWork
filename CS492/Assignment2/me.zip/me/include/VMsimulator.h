#ifndef _VMSIMULATOR_H_
#define _VMSIMULATOR_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

#include "pageData.h"

#define MAX_MEM 512
#define MAX_PAGE_SIZE 32
#define FIFO "FIFO"
#define LRU "LRU"
#define CLOCK "CLOCK"

unsigned long totalPages;

int main (int, char**);
int powerChecker (int);
int numLines (FILE*);
void demandSwap (char*, struct pageTable*, int, int, unsigned long);
void prePagingSwap (char*, struct pageTable*, int, int, unsigned long);

#endif