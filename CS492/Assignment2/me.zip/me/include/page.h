#ifndef _PAGE_H_
#define _PAGE_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* create data structures */
struct fifo
{
    int pageNumber;
    int repChance; /* for Clock page replacement second chance */
    struct fifo* next;
};

struct page
{
    int number;
    int validBit;
    unsigned long timeAccessed; /* for LRU page replacement */
};

struct pageTable
{
    struct page** pages;
    int numPages;
    int numLoaded;
    struct fifo* head; /* for FIFO/Clock page replacement */
};

/* global count of pages, so each page can be given a unique number */
long unsigned int pageSwapCount;

/* declare functions */
struct pageTable* newPTable (int, int);
struct page* newPage ();
void onePage (struct pageTable*, int);
void zeroPage (struct pageTable*, int);
void fPush (struct pageTable*, int);
int poppingOff (struct pageTable*);
int furthestIndex (struct pageTable*);
void cPush (struct pageTable*, int);
int cPop (struct pageTable*);
void clockTime (struct pageTable*, int);
int nextZeroPage (struct pageTable*, int);

#endif
