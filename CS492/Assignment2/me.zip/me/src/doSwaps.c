#include "VMsimulator.h"

/* pre: takes in a char* 'algo', pageTable* 'table', integer 'i', integer 'max'
 *      and unsigned long 'elapsedTime', where 'algo' is either FIFO, LRU,
 *      or CLOCK, 'table' is a valid pageTable*, 'i' is >= 0 and < 'table'->numPages,
 *      'max' is > 0, and elapsedTime is >= 0
 * post: swaps in page 'i' in 'table' using demand paging and 'algo' page replacement
 *      algo
 */
void demandSwap (char* algo, struct pageTable* table, int i, int max, unsigned long elapsedTime)
{
    int x;

    if (!strcmp(algo, FIFO))
    {
        /* invalidate one page */
        x = poppingOff(table);
        if (x > -1)
            zeroPage(table, x);

        /* load the faulted page */
        if (table->numLoaded < max)
        {
            onePage(table, i);
            fPush(table, i);
        }
    }
    else if (!strcmp(algo, LRU))
    {
        /* invalidate one page */
        x = furthestIndex(table);
        if (i > -1)
            zeroPage(table, x);

        /* load the faulted page */
        if (table->numLoaded < max)
        {
            onePage(table, i);
            table->pages[i]->timeAccessed = elapsedTime;
        }
    }
    else /* Clock replacement */
    {
        /* invalidate one page */
        x = cPop(table);
        if (x > -1)
            zeroPage(table, x);

        /* load faulted page */
        if (table->numLoaded < max)
        {
            onePage(table, i);
            cPush(table, i);
        }
    }
}

/* pre: takes in a char* 'algo', pageTable* 'table', integer 'i', integer 'max'
 *      and unsigned long 'elapsedTime', where 'algo' is either FIFO, LRU,
 *      or CLOCK, 'table' is a valid pageTable*, 'i' is >= 0 and < 'table'->numPages,
 *      'max' is > 0, and elapsedTime is >= 0
 * post: swaps in page 'i' in 'table' using pre-paging and 'algo' page replacement
 *      algo
 */
void prePagingSwap (char* algo, struct pageTable* table, int i, int max, unsigned long elapsedTime)
{
    int x;

    if (!strcmp(algo, FIFO))
    {
        /* invalidate two pages */
        x = poppingOff(table);
        if (x > -1)
            zeroPage(table, x);
        x = poppingOff(table);
        if (x > -1)
            zeroPage(table, x);

        /* load the faulted page */
        if (table->numLoaded < max)
        {
            onePage(table, i);
            fPush(table, i);
        }

        /* search for the next page that can be loaded */
        i++;
        if (i == table->numPages)
            i = 0;
        i = nextZeroPage(table, i);
        if (i != -1 && table->numLoaded < max)
        {
            onePage(table, i);
            fPush(table, i);
        }
    }
    else if (!strcmp(algo, LRU))
    {
        /* invalidate two pages */
        x = furthestIndex(table);
        if (x > -1)
            zeroPage(table, x);
        x = furthestIndex(table);
        if (x > -1)
            zeroPage(table, x);

        /* load the faulted page */
        if (table->numLoaded < max)
        {
            onePage(table, i);
            table->pages[i]->timeAccessed = elapsedTime;
        }

        /* search for the next page that can be loaded */
        i++;
        if (i == table->numPages)
            i = 0;
        i = nextZeroPage(table, i);
        if (i != -1 && table->numLoaded < max)
        {
            onePage(table, i);
            table->pages[i]->timeAccessed = elapsedTime;
        }
    }
    else /* Clock replacement */
    {
        /* invalidate two pages */
        x = cPop(table);
        if (x > -1)
            zeroPage(table, x);
        x = cPop(table);
        if (x > -1)
            zeroPage(table, x);

        /* load the faulted page */
        if (table->numLoaded < max)
        {
            onePage(table, i);
            cPush(table, i);
        }

        /* search for the next page that can be loaded */
        i++;
        if (i == table->numPages)
            i = 0;
        i = nextZeroPage(table, i);
        if (i != -1 && table->numLoaded < max)
        {
            onePage(table, i);
            cPush(table, i);
        }
    }
}
