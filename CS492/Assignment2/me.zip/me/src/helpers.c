#include "VMsimulator.h"

//Checks to see if a number is a power of two. In this case, we only check are
// checking memory size.
int powerChecker(int x)
{
     return (x == 1 || x == 2 || x == 4 || x == 8 || x == 16 || x == 32);
}


//gets number of lines in a specified file
int numLines (FILE* file)
{
    int count;
    int i;
    char line;

    count = 0;
    i = 0;

    while (!feof(file))
    {
        line = fgetc(file);
        i++;
        
        if (line == '\n')
        {
            if (i > 1)
            {
                i = 0;
                count++;
            }
        }
    }

    return count;
}

