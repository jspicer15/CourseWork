#include "VMsimulator.h"

//main method for running the program. Simulates a virtual memory management system using
//different page replacement algorithms and methods.
int main (int argc, char** argv)
{
    char* plist;
    char* ptrace;
    int pageSize;
    char* replacementAlgo;
    int prePageToggle; 
    FILE* plistFile;
    FILE* ptraceFile;
    int countLines;
    struct pageTable** pageTables;
    int memLocations;
    unsigned long timeElapsed;
    int i;
    int j;
    char* line;
    size_t len;
    ssize_t ret;
    struct pageTable* pageTableTemp;

    
    if (argc != 6)
    {
        printf("usage: <path to plist> <path to ptrace> <page size> <page replacement algorithm> <pre-paging on/off (+/-)>\n");
        return -1;
    }

    else
    {
        plist = argv[1];
        ptrace = argv[2];
        pageSize = atoi(argv[3]);

        if (pageSize <= 0 || !powerChecker(pageSize) || pageSize > MAX_PAGE_SIZE)
        {
            printf("Error in page size\n");
            printf("Use a power of 2 up to max of 32\n");
            return -1;
        }

        replacementAlgo = argv[4];
        
        if (strcmp(replacementAlgo, FIFO) &&
            strcmp(replacementAlgo, LRU) &&
            strcmp(replacementAlgo, CLOCK))
        {
            printf("Incorrect page replacement algorithmn");
            printf("Use FIFO, LRU, or CLOCK");
            return -1;
        }

        if (!strcmp(argv[5], "+")){
            prePageToggle = 1;
        }

        else if (!strcmp(argv[5], "-")) {
            prePageToggle = 0;
        }

        else
        {
            printf("Incorrect pre-paging value\n");
            printf("Use either + or -\n");
            return -1;
        }

    }

    pageSwapCount = 0;
    plistFile = fopen(plist, "r");

    if (plistFile == NULL)
    {
        printf("Could not find plist file\n");
        return -1;
    }

    ptraceFile = fopen(ptrace, "r");

    if (ptraceFile == NULL)
    {
        printf("Could not find ptrace file\n");
        return -1;
    }

    countLines = numLines(plistFile);

    if (countLines > 0)
    {
        pageTables = (struct pageTable**)malloc(sizeof(struct pageTable*)*countLines);
        if (pageTables == NULL)
        {
            printf("Error allocating memory\n");
            return -1;
        }

        rewind(plistFile);
        i = 0;
        line = NULL;
        len = 0;
        while ((ret = getline(&line, &len, plistFile)) != -1)
        {
            if (!strcmp(line, "\n")) {
                continue;
            }

            strtok(line, " ");
            pageTables[i] = newPTable(pageSize, atoi(strtok(NULL, " ")));

            if (pageTables[i] == NULL)
            {
                printf("Error allocating memory\n");
                return 1;
            }

            i++;
        }

        memLocations = (int)floor((double)MAX_MEM / (countLines * pageSize));

        for (i = 0; i < countLines; i++)
        {
            for (j = 0; j < memLocations && j < pageTables[i]->numPages; j++)
            {
                onePage(pageTables[i], j);

                if (!strcmp(replacementAlgo, FIFO)) {
                    fPush(pageTables[i], j);
                }

                else if (!strcmp(replacementAlgo, CLOCK)) {
                    cPush(pageTables[i], j);
                }
            }

        }

        line = NULL;
        len = 0;
        timeElapsed = 1;

        while ((ret = getline(&line, &len, ptraceFile)) != -1)
        {
            if (!strcmp(line, "\n")) {
                continue;
            }

            i = atoi(strtok(line, " "));
            pageTableTemp = pageTables[i];
            j = atoi(strtok(NULL, " "));
            j = (int)ceil((double)j/pageSize);
            j--;

            if (pageTableTemp->pages[j]->validBit)
            {
                if (!strcmp(replacementAlgo, LRU)) {
                    pageTableTemp->pages[j]->timeAccessed = timeElapsed;
                }

                else if (!strcmp(replacementAlgo, CLOCK)) {
                    clockIndex(pageTableTemp, j);
                }
            }

            else
            {
                pageSwapCount++;

                if (prePageToggle) {
                    prePagingSwap(replacementAlgo, pageTableTemp, j, memLocations, timeElapsed);
                }

                else {
                    demandSwap(replacementAlgo, pageTableTemp, j, memLocations, timeElapsed);
                }
            }

            if (pageTableTemp->numLoaded > memLocations)
            {
                printf("Process exceeded available memory\n");
                return 1;
            }

            timeElapsed++;
        }
    }

    fclose(plistFile);
    fclose(ptraceFile);
    printf("Total page swaps: %lu\n", pageSwapCount);
    return 0;
}
