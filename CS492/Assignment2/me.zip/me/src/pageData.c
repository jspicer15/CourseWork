#include "VMsimulator.h"

//creates a new page table
struct pageTable* newPTable(int tableSize, int numMemLoc)
{
    struct pageTable* table;
    struct page* page;
    int i;
    int numPages = (int)ceil((double)numMemLoc / tableSize);

    table = (struct pageTable*)malloc(sizeof(struct pageTable));
    
    if (table != NULL)
    {
        table->pages = (struct page**)malloc(sizeof(struct page*)*numPages);

        if (table->pages != NULL)
        {
            table->numPages = numPages;
            table->numLoaded = 0;

            for (i = 0; i < numPages; i++)
            {
                page = newPage();

                if (page == NULL)
                {
                    printf("Error allocating memory for new page\n");
                    fflush(stdout);
                    break;
                }

                table->pages[i] = page;
            }

            table->head = NULL;
        }
    }

    return table;
}


//creates a new page
struct page* newPage()
{
    struct page* page;

    page = (struct page*)malloc(sizeof(struct page));

    if (page != NULL)
    {
        if (!totalPages) {
            totalPages = 0;
        }

        page->number = ++totalPages;
        page->validBit = 0;
        page->timeAccessed = 0;
    }

    return page;
}

//sets the validation bit to one
void onePage(struct pageTable* table, int n)
{
    table->pages[n]->validBit = 1;
    table->numLoaded++;
}

//sets the validation bit to zero
void zeroPage(struct pageTable* table, int n)
{
    table->pages[n]->validBit = 0;
    table->numLoaded--;
}

//pushes an item onto the table, specifically for the fifo algorithm
void fPush(struct pageTable* table, int num)
{
    struct fifo* tmp;
    struct fifo* n;

    n = (struct fifo*)malloc(sizeof(struct fifo));

    if (n != NULL)
    {
        n->pageNumber = num;
        n->next = NULL;

        if (table->head == NULL) {
            table->head = n;
        }

        else
        {
            tmp = table->head;

            while (tmp->next != NULL) {
                tmp = tmp->next;
            }

            tmp->next = n;
        }
    }

    else {
        printf("Error allocating memory with struct fifo\n");
    }
}


//pops an item off the table (fifo algorithm)
int poppingOff(struct pageTable* table)
{
    int pageNum;
    struct fifo* tmp;

    pageNum = -1;

    if (table->head != NULL)
    {
        tmp = table->head->next;
        pageNum = table->head->pageNumber;
        free(table->head);
        table->head = tmp;
    }

    return pageNum;
}

//finds the index of the least recently used workable bit
int furthestIndex(struct pageTable* table)
{
    int i;
    int index;
    unsigned long min;

    index = -1;
    min = -1;

    for (i = 0; i < table->numPages; i++)
    {
        if (!table->pages[i]->validBit) {
            continue;
        }

        if (table->pages[i]->timeAccessed < min)
        {
            min = table->pages[i]->timeAccessed;
            index = i;
        }
    }

    return index;
}


//pushes an item onto the table, specifically for the clock algorithm
void cPush(struct pageTable* table, int num)
{
    struct fifo* tmp;
    struct fifo* n;

    n = (struct fifo*)malloc(sizeof(struct fifo));

    if (n != NULL)
    {
        n->pageNumber = num;
        n->repChance = 1;
        n->next = NULL;

        if (table->head == NULL) {
            table->head = n;
        }

        else
        {
            tmp = table->head;

            while (tmp->next != NULL) {
                tmp = tmp->next;
            }

            tmp->next = n;
        }
    }
    else {
        printf("Error pushing with Clock struct fifo\n");
    }
}

//pops an item off the table (for clock algorithm)
int cPop(struct pageTable* table)
{
    int pageNum;
    struct fifo* tmp;
    struct fifo* f;

    pageNum = -1;

    if (table->head != NULL)
    {
        tmp = table->head;

        while (1)
        {
            if (tmp->repChance)
            {
                tmp->repChance = 0;

                if (table->head->next != NULL) {
                    table->head = tmp->next;
                }

                f = tmp;

                while (f->next != NULL) {
                    f = f->next;
                }

                f->next = tmp;
                tmp->next = NULL;
                tmp = table->head;
            }

            else
            {
                pageNum = tmp->pageNumber;
                table->head = tmp->next;
                free(tmp);
                break;
            }
        }
    }

    return pageNum;
}

//gets the index for the clock algorithm
void clockIndex(struct pageTable* table, int num)
{
    struct fifo* tmp;

    if (table->head != NULL)
    {
        tmp = table->head;

        while (tmp->pageNumber != num && tmp->next != NULL) {
            tmp = tmp->next;
        }

        if (tmp->pageNumber == num) {
            tmp->repChance = 1;
        }
    }
}

//gets the index of the next zero page
int nextZeroPage (struct pageTable* table, int s)
{
    int begin;

    begin = s;

    while (table->pages[s]->validBit)
    {
        s = (s + 1) % table->numPages;

        if (s == begin)
        {
            s = -1;
            break;
        }
    }

    return s;
}


//specifies demand paging for the specified page replacement algorithm
void demandSwap (char* algo, struct pageTable* table, int i, int max, unsigned long elapsedTime)
{
    int x;

    if (!strcmp(algo, FIFO))
    {
        x = poppingOff(table);

        if (x > -1) {
            zeroPage(table, x);
        }

        if (table->numLoaded < max)
        {
            onePage(table, i);
            fPush(table, i);
        }
    }

    else if (!strcmp(algo, LRU))
    {
        x = furthestIndex(table);

        if (i > -1) {
            zeroPage(table, x);
        }

        if (table->numLoaded < max)
        {
            onePage(table, i);
            table->pages[i]->timeAccessed = elapsedTime;
        }
    }

    else
    {
        x = cPop(table);

        if (x > -1) {
            zeroPage(table, x);
        }

        if (table->numLoaded < max)
        {
            onePage(table, i);
            cPush(table, i);
        }
    }
}

//specifies pre-paging for the specified page replacement algorithm
void prePagingSwap (char* algo, struct pageTable* table, int i, int max, unsigned long elapsedTime)
{
    int x;

    if (!strcmp(algo, FIFO))
    {
        x = poppingOff(table);

        if (x > -1) {
            zeroPage(table, x);
        }

        x = poppingOff(table);

        if (x > -1) {
            zeroPage(table, x);
        }

        if (table->numLoaded < max)
        {
            onePage(table, i);
            fPush(table, i);
        }

        i++;

        if (i == table->numPages) {
            i = 0;
        }

        i = nextZeroPage(table, i);
        
        if (i != -1 && table->numLoaded < max)
        {
            onePage(table, i);
            fPush(table, i);
        }
    }

    else if (!strcmp(algo, LRU))
    {
        x = furthestIndex(table);

        if (x > -1) {
            zeroPage(table, x);
        }

        x = furthestIndex(table);
        
        if (x > -1) {
            zeroPage(table, x);
        }

        if (table->numLoaded < max)
        {
            onePage(table, i);
            table->pages[i]->timeAccessed = elapsedTime;
        }

        i++;

        if (i == table->numPages) {
            i = 0;
        }

        i = nextZeroPage(table, i);
        
        if (i != -1 && table->numLoaded < max)
        {
            onePage(table, i);
            table->pages[i]->timeAccessed = elapsedTime;
        }
    }

    else
    {
        x = cPop(table);
        
        if (x > -1) {
            zeroPage(table, x);
        }

        x = cPop(table);
        
        if (x > -1) {
            zeroPage(table, x);
        }

        if (table->numLoaded < max)
        {
            onePage(table, i);
            cPush(table, i);
        }

        i++;

        if (i == table->numPages) {
            i = 0;
        }

        i = nextZeroPage(table, i);
        
        if (i != -1 && table->numLoaded < max)
        {
            onePage(table, i);
            cPush(table, i);
        }
    }
}
