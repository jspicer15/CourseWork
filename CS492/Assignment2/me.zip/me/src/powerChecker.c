#include "VMsimulator.h"

int powerChecker(int x)
{
     return (x == 1 || x == 2 || x == 4 || x == 8 || x == 16 || x == 32);
}


/* pre: takes in a FILE* 'file' which must be a valid file, pointing to the plist
 *      input parameter from main
 * post: counts the lines in 'file' which is the number of unique processes in
 *      plist
 * return: an integer of the count of the lines in 'file'
 */
int numLines (FILE* file)
{
    int count;
    int i;
    char line;

    count = 0;
    i = 0;
    while (!feof(file))
    {
        line = fgetc(file);
        i++;
        if (line == '\n')
        {
            if (i > 1)
            {
                i = 0;
                count++;
            }
        }
    }

    return count;
}

