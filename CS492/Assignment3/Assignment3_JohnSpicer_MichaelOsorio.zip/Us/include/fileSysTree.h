#ifndef _FILESYSTREE_H_
#define _FILESYSTREE_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "linkedList.h"

//struct for leaves
struct leafStruct {
    void* data;
    struct leafStruct* parent;
    node* children;
};

typedef struct leafStruct leaf;

leaf* createLeaf(void*);
void  appendLeaf(leaf**, leaf*);
leaf* removeLeaf(leaf**, leaf*);

#endif
