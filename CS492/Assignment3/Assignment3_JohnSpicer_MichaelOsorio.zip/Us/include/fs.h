#ifndef _FS_H_
#define _FS_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/stat.h> 
#include <fcntl.h> 
#include <time.h>

#include "linkedList.h"
#include "fileSysTree.h"

#define PROMPT ">"

#define PATH_SEP '/'

#define CMD_LEN 256

//block struct
struct blockStruct {
    int s_addr; /* start address */
    int e_addr; /* end address */
    char isFree;
};

typedef struct blockStruct block;

//file struct
struct fileStruct {
    char* name;
    int size;
    int allocatedBlocks;
    time_t timestamp;
    char isDirectory;
    node* lfile; 
};

typedef struct fileStruct sysFile;

//global environment struct
struct s_env {
    char* exe;
    int fileList;
    int dirList;
    int diskSize;
    int blockSize;
    int blockNum;
    node* diskList;
    leaf* fileSysTree;
    leaf* currDir;
} gl;

int         main(int, char**);
void        usage(char*);
void        runSetup(int, char**);
void        startParse();
char**      str2vect(char*);
void        freeVector(char**);
block*   createBlock(int, int, char);
sysFile*    createFile(char*, int, char);
void        nodeSplit(int);
void        nodeMerges();
void        allocBlocks(sysFile*);
leaf*       findLeaf(leaf*, char*);
void        addLeaf(sysFile*);
int         countSep(char*);
char*       traceForPath(sysFile*);
void        changeDir(char*);
void        listFiles();
void        makeDir(char*);
void        create(char*);
void        append(char*, int);
void        removeBytes(char*, int);
void        deleteFiles(char*);
void        filesExit();
void        direc();
void        printFiles();
void        printDisk();

#endif
