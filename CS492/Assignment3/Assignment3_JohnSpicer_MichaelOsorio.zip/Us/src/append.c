/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//appends number of bytes to specified file
void append(char* file, int bytes)
{
    leaf* target;

    if (bytes < 0)
    {
        printf("usage: append name size\n");
        fflush(stdout);
    }
    else if ((target = findLeaf(gl.currDir, file)) != NULL)
    {
        if (!(((sysFile*)(target->data))->isDirectory))
        {
            ((sysFile*)(target->data))->size += bytes;
            allocBlocks((sysFile*)(target->data));
            ((sysFile*)(target->data))->timestamp = time(NULL);
        }
    }
    else if (target == NULL)
    {
        printf("%s: append: no such file or directory: %s\n", gl.exe, file);
        fflush(stdout);
    }
}

