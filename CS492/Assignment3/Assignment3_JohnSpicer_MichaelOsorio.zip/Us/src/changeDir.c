/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//change directory function
void changeDir(char* dir)
{
    leaf* l;

    if (!strcmp(dir, ".."))
    {
        if ((l = gl.currDir->parent) != NULL)
            gl.currDir = l;
        else
        {
            printf("%s: cd: no such file or directory: %s\n", gl.exe, dir);
            fflush(stdout);
        }
    }
    else
    {
        if ((l = findLeaf(gl.currDir, dir)) != NULL)
            gl.currDir = l;
        else
        {
            printf("%s: cd: no such file or directory: %s\n", gl.exe, dir);
            fflush(stdout);
        }
    }
}

