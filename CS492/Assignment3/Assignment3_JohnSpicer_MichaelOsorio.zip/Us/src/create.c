/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//creates a new file in the current directory
void create(char* name)
{
    if (findLeaf(gl.currDir, name) != NULL)
    {
        printf("%s: create: cannot create file `%s`: File exists\n", gl.exe, name);
        fflush(stdout);
    }
    //add to hierarchy
    else
        addLeaf(createFile(name, 0, 0));
}

