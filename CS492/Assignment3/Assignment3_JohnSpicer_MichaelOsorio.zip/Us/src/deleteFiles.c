/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//deletes the specified file
void deleteFiles(char* name)
{
    leaf* t;
    leaf* p;

    if ((t = findLeaf(gl.currDir, name)) != NULL)
    {
        if (((sysFile*)(t->data))->isDirectory && t->children != NULL)
        {
            printf("%s: delete: cannot delete `%s`: Directory is not empty\n",
                    gl.exe, name);
            fflush(stdout);
        }
        else
        {
            if ((p = t->parent) != NULL)
                ((sysFile*)(p->data))->timestamp = time(NULL);
        }
    }
    else
    {
        printf("%s: delete: cannot delete file `%s`: no such file or directory\n",
                gl.exe, name);
        fflush(stdout);
    }
}

