/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//prints out directory tree
void direc()
{
    leaf* t;
    node* n;
    sysFile* f;
    node* neighbors;

    neighbors = NULL;
    t = gl.fileSysTree;

    while (t != NULL)
    {
        f = (sysFile*)(t->data);
        printf("%s\n", traceForPath(f));
        fflush(stdout);

        if ((n = t->children) != NULL)
        {
            do
            {
                appendNode(&neighbors, createNode(n->data));
            } while ((n = n->next) != NULL);
        }

        if ((n = popNode(&neighbors)) != NULL)
        {
            t = (leaf*)(n->data);
        }
        else
            t = NULL;
    }
}

