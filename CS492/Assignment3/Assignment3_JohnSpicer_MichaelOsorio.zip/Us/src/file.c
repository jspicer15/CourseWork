/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//creates a block with a start and end address and an indicator if the block is free or not
block* createBlock(int s, int e, char isFree)
{
    block* ret;

    if ((ret = (block*)malloc(sizeof(block))) != NULL)
    {
        ret->s_addr = s;
        ret->e_addr = e;
        ret->isFree = isFree;
    }

    return ret;
}

//creates a file with a name, size, and an indicator that tell is the file
//is a normal file or a directory
sysFile* createFile(char* name, int size, char isDirectory)
{
    sysFile* ret;

    if ((ret = (sysFile*)malloc(sizeof(sysFile))) != NULL)
    {
        ret->name = strdup(name);
        ret->size = size;
        ret->allocatedBlocks = 0;
        ret->timestamp = time(NULL);
        ret->isDirectory = isDirectory;
        ret->lfile = NULL;
    }

    return ret;
}

//splits the disk at index and starts a new node
void nodeSplit(int index)
{
    node* n;
    block* b;

    n = gl.diskList;
    b = (block*)(n->data);

    if (index < b->e_addr && index >= b->s_addr)
    {
        b->s_addr = index;
        prependNode(&gl.diskList, createNode((void*)createBlock(0, index, 0)));
    }
    else
    {
        for (; n != NULL; n = n->next)
        {
            b = (block*)(n->data);
            if (index < b->e_addr && index >= b->s_addr)
                break;
        }

        if (n != NULL)
        {
            insertNode(n, createNode((void*)createBlock(index, b->e_addr, 1)));
            b->e_addr = index;
            b->isFree = 0;
        }
    }
}

//merges nodes that are in the same free state
void nodeMerges()
{
    node* n;
    block* b; 
    block* nb;

    n = gl.diskList;
    b = (block*)(n->data);

    while (n != NULL && n->next != NULL)
    {
        nb = (block*)(n->next->data);

        if (b->isFree == nb->isFree)
        {
            b->e_addr = nb->e_addr;
            free(removeBytesNode(n, n->next));
        }

        n = n->next;
    }
}

//allocates blocks for the specified file
void allocBlocks(sysFile* file)
{
    int blockNumNeeded;
    int i; 
    block* b; 
    node* n;

    blockNumNeeded = (file->size / gl.blockSize) - file->allocatedBlocks;
    n = gl.diskList;
    while (blockNumNeeded > 0)
    {
        for (; n != NULL && !(((block*)(n->data))->isFree); n = n->next)
            ;

        if (n == NULL)
        {
            fflush(stderr);

            break;
        }
        else
        {
            b = (block*)(n->data);

            if (b->e_addr - b->s_addr > blockNumNeeded)
            {
                for (i = b->s_addr; i < b->s_addr + blockNumNeeded; i++)
                    appendNode(&(file->lfile), createNode((void*)createBlock(i, i + 1, 0)));

                file->allocatedBlocks += blockNumNeeded;

                nodeSplit(b->s_addr + blockNumNeeded);
                blockNumNeeded -= blockNumNeeded;
            }
            else
            {
                file->allocatedBlocks += b->e_addr - b->s_addr;
                blockNumNeeded -= b->e_addr - b->s_addr;

                for (i = b->s_addr; i < b->e_addr; i++)
                    appendNode(&(file->lfile), createNode((void*)createBlock(i, i + 1, 0)));

                b->isFree = 0;
            }
        }
    }

    nodeMerges();
}

//finds the file node in the tree
leaf* findLeaf(leaf* start, char* name)
{
    leaf* ret;
    leaf* t;
    node* n;
    node* neighbors;

    ret = NULL;
    neighbors = NULL;
    t = start;

    while (t != NULL && strcmp(name, ((sysFile*)(t->data))->name))
    {
        if ((n = t->children) != NULL)
        {
            do
            {
                appendNode(&neighbors, createNode(n->data));
            } while ((n = n->next) != NULL);
        }

        if ((n = popNode(&neighbors)) != NULL)
        {
            t = (leaf*)(n->data);
        }
        else
            t = NULL;
    }

    if (t != NULL)
        ret = t;

    return ret;
}

//adds file to the file hierarchy tree and places it in the appropriate position
void addLeaf(sysFile* file)
{
    char* name;
    char* part;
    char delim[2];
    leaf* l;
    leaf** pd;
    int p;

    pd = NULL;
    if (file != NULL)
    {
        delim[0] = PATH_SEP;
        delim[1] = '\0';
        name = strdup(file->name);

        if ((p = countSep(name)))
        {
            part = strtok(name, delim);
            if (part == NULL)
                part = delim;
            if ((l = findLeaf(gl.fileSysTree, part)) != NULL)
                pd = &l;
            while (p--)
            {
                part = strtok(NULL, delim);
                if (p > 0)
                    if ((l = findLeaf(gl.fileSysTree, part)) != NULL)
                        pd = &l;
            }

            if (pd == NULL || (*pd) == NULL)
            {
                fprintf(stderr, "%s: could not find directory\n", gl.exe);
                fflush(stderr);

                return;
            }
            else
            {
                file->name = strcpy(file->name, part);
            }
        }
        else
        {
            if (gl.currDir != NULL)
                pd = &gl.currDir;
            else
                pd = &gl.fileSysTree;
        }


        free(name);

        appendLeaf(pd, createLeaf((void*)file));
    }
}


//count occurences of separators
int countSep(char* fname)
{
    int count;
    int i;

    count = 0;
    for (i = 0; i < strlen(fname); i++)
        if (fname[i] == PATH_SEP)
            count++;

    return count;
}

//make full path of file from the tree
char* traceForPath(sysFile* file)
{
    char* ret;
    char* parent;
    leaf* target;

    ret = (char*)malloc(1024*sizeof(char));
    target = findLeaf(gl.fileSysTree, file->name);

    if (target->parent != NULL)
    {
        parent = traceForPath((sysFile*)target->parent->data);
        if (file->isDirectory)
        {
            sprintf(ret, "%s%s%c",
                    parent,
                    file->name,
                    PATH_SEP);
        }
        else
        {
            sprintf(ret, "%s%s",
                    parent,
                    file->name);
        }
    }
    else
    {
        if (file->isDirectory)
        {
            sprintf(ret, "%s%c",
                    file->name,
                    PATH_SEP);
        }
        else
        {
            sprintf(ret, "%s",
                    file->name);
        }
    }

    return ret;
}

