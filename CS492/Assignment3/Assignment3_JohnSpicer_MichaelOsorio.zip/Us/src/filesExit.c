/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//exits the program
void filesExit()
{
    node* n;
    node* neighbors;
    sysFile* f;
    leaf* t;

    //closes here
    close(gl.fileList);
    close(gl.dirList);

    while ((n = popNode(&gl.diskList)) != NULL)
        free(n);

    t = gl.fileSysTree;
    neighbors = NULL;
    while (t != NULL)
    {
        f = (sysFile*)(t->data);

        free(f->name);
        while ((n = popNode(&(f->lfile))) != NULL)
            free(n);
        free(f);

        if ((n = t->children) != NULL)
        {
            do
            {
                appendNode(&neighbors, createNode(n->data));
            } while ((n = n->next) != NULL);
        }

        free(t);

        if ((n = popNode(&neighbors)) != NULL)
        {
            t = (leaf*)(n->data);
        }
        else
            t = NULL;
    }
}

