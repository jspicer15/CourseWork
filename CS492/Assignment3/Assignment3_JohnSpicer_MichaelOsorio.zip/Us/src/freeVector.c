/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//frees the strings in vect and then frees vect
void freeVector(char** vect)
{
	int i;

	for (i = 0; vect[i] != NULL; i++)
		free(vect[i]);
	free(vect[i]);
	free(vect);
}

