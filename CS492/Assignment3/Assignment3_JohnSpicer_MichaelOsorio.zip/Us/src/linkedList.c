/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"

//creates a node holding the specified data
node* createNode(void* data)
{
    node* ret;

    ret = NULL;
    if (data != NULL)
    {
        if ((ret = (node*)malloc(sizeof(node))) != NULL)
        {
            ret->data = data;
            ret->next = NULL;
        }
    }

    return ret;
}

//appends a node to the end of the linked list
void appendNode(node** list, node* n)
{
    node* tmp;

    if (n != NULL)
    {
        if ((*list) == NULL)
            (*list) = n;
        else
        {
            for (tmp = (*list); tmp->next != NULL; tmp = tmp->next)
                ;
            tmp->next = n;
        }
    }
}

//adds a node to the beginning of the linked list
void prependNode(node** list, node* n)
{
    n->next = (*list);
    (*list) = n;
}

//inserts a node after the specified node
void insertNode(node* first, node* second)
{
    second->next = first->next;
    first->next = second;
}

//pops a node from the list
node* popNode(node** list)
{
    node* ret;

    ret = NULL;
    if ((*list) != NULL)
    {
        ret = (*list);
        (*list) = (*list)->next;
    }

    return ret;
}

//removes a node after the specified node
node* removeBytesNode(node* first, node* second)
{
    node* ret;

    ret = second;
    first->next = second->next;
    second->next = NULL;

    return ret;
}

