/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//lists the files in the current directory
void listFiles()
{
    node* n;

    n = NULL;
    if ((n = gl.currDir->children) != NULL)
    {
        do
        {
            if (((sysFile*)(((leaf*)(n->data))->data))->isDirectory)
                printf("%s%c\n", ((sysFile*)(((leaf*)(n->data))->data))->name, PATH_SEP);
            else
                printf("%s\n", ((sysFile*)(((leaf*)(n->data))->data))->name);
        }
        while ((n = n->next) != NULL);
        fflush(stdout);
    }
}

