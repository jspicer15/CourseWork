/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//simulates a file system
int main(int argc, char** argv)
{
    int n;
    char* line;
    char** v;

    //calls the program for simulation
    runSetup(argc, argv);

    startParse();

    line = (char*)malloc(CMD_LEN * sizeof(char));
    bzero((void*)line, CMD_LEN * sizeof(char));
    while (1)
    {
        printf("%s ", PROMPT);
        fflush(stdout);

        if ((n = read(0, line, CMD_LEN)) == -1)
        {
            perror(argv[0]);

            filesExit();
            exit(-1);
        }
        else if (n == 0)
        {
            filesExit();
            break;
        }
        else
        {
            line[n - 1] = '\0';
            //makes line into a vector
            v = str2vect(line);

            //run append
            if (!strcmp(v[0], "append"))
            {
                if (v[1] != NULL && v[2] != NULL)
                    append(v[1], atoi(v[2]));
                else
                {
                    printf("usage: append name size\n");
                    fflush(stdout);
                }
            }
            //run change directory
            else if (!strcmp(v[0], "cd"))
            {
                if (v[1] != NULL)
                    changeDir(v[1]);
                else
                {
                    printf("usage: cd directory\n");
                    fflush(stdout);
                }
            }
            else if (!strcmp(v[0], "cd.."))
            {
                changeDir("..");
            }
            //run create
            else if (!strcmp(v[0], "create"))
            {
                if (v[1] != NULL)
                    create(v[1]);
                else
                {
                    printf("usage: create name\n");
                    fflush(stdout);
                }
            }
            //run delete
            else if (!strcmp(v[0], "delete"))
            {
                if (v[1] != NULL)
                    deleteFiles(v[1]);
                else
                {
                    printf("usage: delete name\n");
                    fflush(stdout);
                }
            }
            //get current directory
            else if (!strcmp(v[0], "dir"))
            {
                direc();
            }
            //exit
            else if (!strcmp(v[0], "exit"))
            {
                freeVector(v);
                break;
            }
            //run list
            else if (!strcmp(v[0], "ls"))
            {
                listFiles();
            }
            //run make directory
            else if (!strcmp(v[0], "mkdir"))
            {
                if (v[1] != NULL)
                    makeDir(v[1]);
                else
                {
                    printf("usage: mkdir directory\n");
                    fflush(stdout);
                }
            }
            //run print disk
            else if (!strcmp(v[0], "prdisk"))
            {
                printDisk();
            }
            //run print file
            else if (!strcmp(v[0], "prfiles"))
            {
                printFiles();
            }
            //run remove bytes
            else if (!strcmp(v[0], "removeBytes"))
            {
                if (v[1] != NULL && v[2] != NULL)
                    removeBytes(v[1], atoi(v[2]));
                else
                {
                    printf("usage: removeBytes name size\n");
                    fflush(stdout);
                }
            }
            //not a correct command
            else
            {
                printf("%s: command not found: %s\n", argv[0], v[0]);
                fflush(stdout);
            }

            freeVector(v);
        }
    }
    free(line);

    filesExit();
    return 0;
}

