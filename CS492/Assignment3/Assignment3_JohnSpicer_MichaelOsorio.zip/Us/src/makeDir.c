/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//creates a new directory inside of the current directory
void makeDir(char* name)
{
    if (findLeaf(gl.currDir, name) != NULL)
    {
        printf("%s: mkdir: cannot create directory `%s`: File exists\n", gl.exe, name);
        fflush(stdout);
    }
    //if the specified directory does not already exist go to the else statment
    else
        addLeaf(createFile(name, 0, 1));
}

