/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//print disk information
void printDisk()
{
    leaf* t;
    sysFile* f;
    node* n;
    node* neighbors;
    block* b;
    int frag;

    frag = 0;
    neighbors = NULL;

    for (n = gl.diskList; n != NULL; n = n->next)
    {
        b = (block*)(n->data);
        if (b->isFree)
        {
            printf("Free:\t%d-%d\n", b->s_addr, b->e_addr - 1);
        }
        else
        {
            printf("In Use:\t%d-%d\n", b->s_addr, b->e_addr - 1);
        }
    }

    t = gl.fileSysTree;

    while (t != NULL)
    {
        f = (sysFile*)(t->data);

        if (f->size % gl.blockSize)
        {
            frag += f->size % gl.blockSize;
        }

        if ((n = t->children) != NULL)
        {
            do
            {
                appendNode(&neighbors, createNode(n->data));
            } while ((n = n->next) != NULL);
        }

        if ((n = popNode(&neighbors)) != NULL)
        {
            t = (leaf*)(n->data);
        }
        else
            t = NULL;
    }

    printf("Fragmentation: %d\n", frag);
    fflush(stdout);
}

