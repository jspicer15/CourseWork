/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//print file and all file information
void printFiles()
{
    leaf* t;
    node* n;
    sysFile* f;
    node* neighbors;

    neighbors = NULL;
    t = gl.fileSysTree;

    while (t != NULL)
    {
        f = (sysFile*)(t->data);
        printf("%s\t%d blocks\t%d bytes\t%ld timestamp\n",
                traceForPath(f),
                f->allocatedBlocks,
                f->size,
                f->timestamp);
        printf("\tBlock addresses: ");
        for (n = f->lfile; n != NULL; n = n->next)
        {
            printf("%d ", ((block*)(n->data))->s_addr);
        }
        printf("\n");
        fflush(stdout);

        if ((n = t->children) != NULL)
        {
            do
            {
                appendNode(&neighbors, createNode(n->data));
            } while ((n = n->next) != NULL);
        }

        if ((n = popNode(&neighbors)) != NULL)
        {
            t = (leaf*)(n->data);
        }
        else
            t = NULL;
    }
}

