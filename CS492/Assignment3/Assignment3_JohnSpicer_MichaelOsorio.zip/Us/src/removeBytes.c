/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//removes specified number of bytes from the file
void removeBytes(char* file, int bytes)
{
    leaf* target;

    if (bytes < 0)
    {
        printf("usage: removeBytes name size\n");
        fflush(stdout);
    }
    else if ((target = findLeaf(gl.currDir, file)) != NULL)
    {
        if (!(((sysFile*)(target->data))->isDirectory))
        {
            ((sysFile*)(target->data))->size -= bytes;
            ((sysFile*)(target->data))->timestamp = time(NULL);
        }
    }
    else if (target == NULL)
    {
        printf("%s: removeBytes: no such file or directory: %s\n", gl.exe, file);
        fflush(stdout);
    }
}

