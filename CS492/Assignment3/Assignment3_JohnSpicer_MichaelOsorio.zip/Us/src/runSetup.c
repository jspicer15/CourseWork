/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//command line arguments including file list (-f), dir_list (-d), disk size (-s), and
//block size (-b) and global environment
void runSetup(int argc, char** argv)
{
    int opt;


    //checks number of arguments
    if (argc != 9)
    {   
        printf("usage: -f file_list -d dir_list -s disk_size -b block_size");
        printf(argv[0]);
        exit(-1);
    }


    while ((opt = getopt(argc, argv, "f:d:s:b:")) != -1)
    {
        switch (opt)
        {
            case 'f':
                if ((gl.fileList = open(optarg, O_RDONLY)) < 0)
                {
                    perror(argv[0]);

                    exit(-1);
                }
                break;
            case 'd':
                if ((gl.dirList = open(optarg, O_RDONLY)) < 0)
                {
                    perror(argv[0]);

                    exit(-1);
                }
                break;
            case 's':
                gl.diskSize = atoi(optarg);
                break;
            case 'b':
                gl.blockSize = atoi(optarg);
                break;
            default: /* invalid option */
                printf("usage: -f file_list -d dir_list -s disk_size -b block_size");
                printf(argv[0]);
                exit(-1);
        }
    }

    gl.exe = argv[0];
}

