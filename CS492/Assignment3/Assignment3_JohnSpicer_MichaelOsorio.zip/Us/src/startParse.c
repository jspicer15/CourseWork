/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fs.h"

//parses the needed diles to the global file hierarchy
void startParse()
{
    ssize_t n;
    size_t s;
    char* line;
    char** vect;
    FILE* dir_stream;
    FILE* file_stream;
    sysFile* f;
    gl.fileSysTree = NULL;

    gl.currDir = NULL;

    gl.blockNum = gl.diskSize / gl.blockSize;

    gl.diskList = NULL;
    appendNode(&gl.diskList, createNode((void*)createBlock(0, gl.blockNum, 1)));

    if ((dir_stream = fdopen(gl.dirList, "r")) == NULL)
    {
        perror(gl.exe);

        exit(-1);
    }

    if ((file_stream = fdopen(gl.fileList, "r")) == NULL)
    {
        perror(gl.exe);

        exit(-1);
    }

    line = NULL;
    s = 0;
    while ((n = getline(&line, &s, dir_stream)) != 0)
    {
        if (n < 0 && !feof(dir_stream))
        {
            perror(gl.exe);

            exit(-1);
        }
        else if (feof(dir_stream))
            break;

        line[n - 1] = '\0';

        addLeaf(createFile(line, 0, 1));

        free(line);
        line = NULL;
        s = 0;
    }

    line = NULL;
    s = 0;
    while ((n = getline(&line, &s, file_stream)) != 0)
    {
        if (n < 0 && !feof(file_stream))
        {
            perror(gl.exe);

            exit(-1);
        }
        else if (feof(file_stream))
            break;

        line[n - 1] = '\0';

        vect = str2vect(line);
        f = createFile(vect[10], atoi(vect[6]), 0);

        addLeaf(f);
        allocBlocks(f);

        freeVector(vect);
        free(line);
        line = NULL;
        s = 0;
    }
    gl.currDir = gl.fileSysTree;
}

