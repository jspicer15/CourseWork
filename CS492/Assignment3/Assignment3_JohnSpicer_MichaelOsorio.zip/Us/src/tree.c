/*
John Spicer
Michael Osorio
*/

#include "linkedList.h"
#include "fileSysTree.h"

//creates a leaf for the file system tree
leaf* createLeaf(void* data)
{
    leaf* ret;

    ret = NULL;
    if (data != NULL)
    {
        if ((ret = (leaf*)malloc(sizeof(leaf))) != NULL)
        {
            ret->data = data;
            ret->parent = NULL;
            ret->children = NULL;
        }
    }

    return ret;
}

//appends a leaf to the tree
void appendLeaf(leaf** fileSysfileSysTree, leaf* l)
{
    if (l != NULL)
    {
        if ((*fileSysfileSysTree) == NULL)
            (*fileSysfileSysTree) = l;
        else
        {
            l->parent = (*fileSysfileSysTree);
            appendNode(&((*fileSysfileSysTree)->children), createNode((void*)l));
        }
    }
}

//removes the specified leaf from the tree
leaf* removeLeaf(leaf** fileSysfileSysTree, leaf* l)
{
    leaf* ret;
    node* n;
    node* neighbors;

    ret = NULL;
    if (l != NULL)
    {
        if ((*fileSysfileSysTree) != NULL) 
        {
            if ((*fileSysfileSysTree) == l)
            {
                ret = (*fileSysfileSysTree);
                fileSysfileSysTree = NULL;
            }
            else
            {
                if ((n = (*fileSysfileSysTree)->children) != NULL)
                {
                    do
                    {
                        appendNode(&neighbors, n);
                    } while ((n = n->next) != NULL);

                    while ((n = popNode(&neighbors)) != NULL)
                    {
                        if (n->data == l)
                        {
                            ret = (leaf*)n->data;
                            break;
                        }
                        else if ((n = ((leaf*)(n->data))->children) != NULL)
                        {
                            do
                            {
                                appendNode(&neighbors, n);
                            } while ((n = n->next) != NULL);
                        }
                    }
                }
            }
        }
    }

    return ret;
}

