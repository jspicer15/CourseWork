#ifndef _FILESYSTREE_H_
#define _FILESYSTREE_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "linkedList.h"

struct leafStruct {
    void* data;
    struct leafStruct* parent;
    node* children; /* a linked_list which holds other leaves */
};

typedef struct leafStruct leaf;

leaf* createLeaf(void*);
void  appendLeaf(leaf**, leaf*);
leaf* removeLeaf(leaf**, leaf*);

#endif /* _fileSysTree_H_ */
