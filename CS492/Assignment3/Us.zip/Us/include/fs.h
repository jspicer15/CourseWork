#ifndef _FS_H_
#define _FS_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h> /* for open */
#include <sys/stat.h> /* for open */
#include <fcntl.h> /* for open */
#include <time.h>

#include "linkedList.h"
#include "fileSysTree.h"

/* constant for the prompt string */
#define PROMPT ">"

/* constant for the directory path separator character */
#define PATH_SEP '/'

/* constant for the max length (in charcters) of a single command */
#define CMD_LEN 256

/* struct to define a 'block'
 *      end address should be the next start address, e.g. a single block with
 *      `s_addr = n` will have `e_addr = n + 1`
 */
struct blockStruct {
    int s_addr; /* start address */
    int e_addr; /* end address */
    char isFree;
};

/* avoid typing `struct` everywhere */
typedef struct blockStruct block;

/* struct to define a 'file' */
struct fileStruct {
    char* name;
    int size; /* file size in bytes */
    int allocatedBlocks;
    time_t timestamp;
    char isDirectory;
    node* lfile; /* linked_list of block addresses */
};

/* avoid typing `struct` everywhere */
typedef struct fileStruct sysFile;

/* global environment wrapper */
struct s_env {
    char* exe; /* name of the exe file */
    int fileList; /* file descriptor for file_list.txt */
    int dirList; /* file descriptor for dir_list.txt */
    int diskSize; /* disk size */
    int blockSize; /* block size */
    int blockNum; /* total number of blocks (diskSize/blockSize) */
    node* diskList; /* lined_list for disk blocks */
    leaf* fileSysTree; /* filesystem hierarchy */
    leaf* currDir; /* the fileSysfileSysTree node for the current directory */
} gl;

/* functions ================================================================ */
int         main(int, char**);
void        usage(char*);
void        runSetup(int, char**);
void        init();
char**      str2vect(char*);
void        freeVector(char**);

/* grouped in file.c */
block*   createBlock(int, int, char);
sysFile*    createFile(char*, int, char);
void        splitdiskListNode(int);
void        mergediskListNodes();
void        allocateFile(sysFile*);
leaf*       findInHierarchy(leaf*, char*);
void        addToHierarchy(sysFile*);
int         countPathSeparations(char*);
char*       getFullPath(sysFile*);

/* functions for handling user commands */
void        fs_cd(char*);
void        fs_ls();
void        fs_mkdir(char*);
void        create(char*);
void        append(char*, int);
void        removeBytes(char*, int);
void        deleteFiles(char*);
void        fs_exit();
void        direc();
void        fs_prfiles();
void        printDisk();

#endif /* _FS_H_ */
