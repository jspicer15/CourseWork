#ifndef _LINKEDLIST_H_
#define _LINKEDLIST_H_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

struct nodeStruct {
    void* data;
    struct nodeStruct* next;
};

typedef struct nodeStruct node;

node*   createNode(void*);
void    appendNode(node**, node*);
void    prependNode(node**, node*);
void    insertNode(node*, node*);
node*   popNode(node**);
node*   removeBytesNode(node*, node*);

#endif /* _LINKED_LIST_H_ */
