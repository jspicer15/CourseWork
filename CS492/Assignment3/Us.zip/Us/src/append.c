#include "fs.h"

/* pre: takes in a char* 'file' and an int 'bytes'
 * post: appends 'bytes' number of bytes to the file 'file'
 */
void append(char* file, int bytes)
{
    leaf* target;

    if (bytes < 0)
    {
        printf("usage: append name size\n");
        fflush(stdout);
    }
    else if ((target = findInHierarchy(gl.currDir, file)) != NULL)
    {
        /* only append to regular files */
        if (!(((sysFile*)(target->data))->isDirectory))
        {
            ((sysFile*)(target->data))->size += bytes;
            allocateFile((sysFile*)(target->data));
            ((sysFile*)(target->data))->timestamp = time(NULL);
        }
    }
    else if (target == NULL)
    {
        printf("%s: append: no such file or directory: %s\n", gl.exe, file);
        fflush(stdout);
    }
}

