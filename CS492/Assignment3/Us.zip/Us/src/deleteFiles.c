#include "fs.h"

/* pre: takes in a char* 'name'
 * post: deletes the file or directory referenced by 'name'
 */
void deleteFiles(char* name)
{
    leaf* t;
    leaf* p;

    if ((t = findInHierarchy(gl.currDir, name)) != NULL)
    {
        if (((sysFile*)(t->data))->isDirectory && t->children != NULL)
        {
            printf("%s: delete: cannot delete `%s`: Directory is not empty\n",
                    gl.exe, name);
            fflush(stdout);
        }
        else
        {
            if ((p = t->parent) != NULL)
                ((sysFile*)(p->data))->timestamp = time(NULL);

            /* TODO: actually removeBytes t */
            /* removeBytesLeaf(&gl.fileSysTree, t); */
        }
    }
    else
    {
        printf("%s: delete: cannot delete file `%s`: no such file or directory\n",
                gl.exe, name);
        fflush(stdout);
    }
}

