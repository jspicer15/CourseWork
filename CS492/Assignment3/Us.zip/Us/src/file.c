#include "fs.h"

/* pre: takes in an int 's', int 'e' and char 'isFree' which should only have
 *      the values zero or one (respectively false or true)
 * post: creates a new block with the start address of 's', end address of
 *      'e' and 'isFree' to signify if this block is free or used
 * return: a block* pointing to the newly allocated block, or NULL on error
 */
block* createBlock(int s, int e, char isFree)
{
    block* ret;

    if ((ret = (block*)malloc(sizeof(block))) != NULL)
    {
        ret->s_addr = s;
        ret->e_addr = e;
        ret->isFree = isFree;
    }

    return ret;
}

/* pre: takes in a char* 'name', int 'size' and char 'isDirectory' which should
 *      only have the values zero or one (respectively false or true)
 * post: creates an new sysFile with the name 'name' of size 'size' and
 *      'isDirectory' to signify if this file is a regular file or a directory
 * return: a sysFile* pointing to the newly allocated file, or NULL on error
 */
sysFile* createFile(char* name, int size, char isDirectory)
{
    sysFile* ret;

    if ((ret = (sysFile*)malloc(sizeof(sysFile))) != NULL)
    {
        ret->name = strdup(name); /* make sure this gets freed */
        ret->size = size;
        ret->allocatedBlocks = 0; /* file hasn't been allocated yet */
        ret->timestamp = time(NULL);
        ret->isDirectory = isDirectory;
        ret->lfile = NULL; /* empty linked_list */
    }

    return ret;
}

/* pre: takes in an int 'index' and gl.diskList has been created
 * post: splits gl.diskList at 'index' such that 'index' starts a new node in
 *      gl.diskList, and sets the block on the left of the split as used
 */
void splitdiskListNode(int index)
{
    node* n; /* temp node */
    block* b; /* temp block */

    n = gl.diskList;
    b = (block*)(n->data);

    /* if first node needs to be split */
    if (index < b->e_addr && index >= b->s_addr)
    {
        b->s_addr = index;
        prependNode(&gl.diskList, createNode((void*)createBlock(0, index, 0)));
    }
    else
    {
        /* while node is not NULL and index is not in this block */
        for (; n != NULL; n = n->next)
        {
            b = (block*)(n->data);
            if (index < b->e_addr && index >= b->s_addr)
                break;
        }

        if (n != NULL)
        {
            insertNode(n, createNode((void*)createBlock(index, b->e_addr, 1)));
            b->e_addr = index;
            b->isFree = 0;
        }
        /* else fail silently, future me might hate me for this */
    }
}

/* pre: gl.diskList has been created
 * post: merges all contiguous nodes in gl.diskList that are in the same state
 *      (free/used)
 */
void mergediskListNodes()
{
    node* n; /* temp node */
    block* b; /* temp block */
    block* nb; /* temp next block */

    n = gl.diskList;
    b = (block*)(n->data);

    while (n != NULL && n->next != NULL)
    {
        nb = (block*)(n->next->data);

        /* if this block and the next block have the same state, merge them */
        if (b->isFree == nb->isFree)
        {
            b->e_addr = nb->e_addr;
            free(removeBytesNode(n, n->next));
        }

        n = n->next;
    }
}

/* pre: takes in a sysFile* 'file' that has been initialized, and gl.diskList has
 *      been created
 * post: allocates blocks for 'file'
 */
void allocateFile(sysFile* file)
{
    int blockNumNeeded; /* the number of blocks needed by the file */
    int i; /* loop counter */
    block* b; /* temp block */
    node* n; /* temp node */

    blockNumNeeded = (file->size / gl.blockSize) - file->allocatedBlocks;
    n = gl.diskList;
    /* only allocate if the number of needed blocks has changed */
    while (blockNumNeeded > 0)
    {
        /* iterate forward over gl.diskList to find the next free node */
        for (; n != NULL && !(((block*)(n->data))->isFree); n = n->next)
            ; /* note empty loop */

        /* if we reached the end without allocating the whole file */
        if (n == NULL)
        {
            fprintf(stderr, "%s: Out of space\n", gl.exe);
            fflush(stderr);

            break;
        }
        else
        {
            b = (block*)(n->data);

            /* if only part of the node is needed */
            if (b->e_addr - b->s_addr > blockNumNeeded)
            {
                /* update file->lfile */
                for (i = b->s_addr; i < b->s_addr + blockNumNeeded; i++)
                    appendNode(&(file->lfile), createNode((void*)createBlock(i, i + 1, 0)));

                file->allocatedBlocks += blockNumNeeded;

                /* update gl.diskList */
                splitdiskListNode(b->s_addr + blockNumNeeded);
                blockNumNeeded -= blockNumNeeded;
            }
            else /* else the whole node is needed */
            {
                file->allocatedBlocks += b->e_addr - b->s_addr;
                blockNumNeeded -= b->e_addr - b->s_addr;

                /* update file->lfile */
                for (i = b->s_addr; i < b->e_addr; i++)
                    appendNode(&(file->lfile), createNode((void*)createBlock(i, i + 1, 0)));

                /* update gl.diskList */
                b->isFree = 0;
            }
        }
    }

    /* merge nodes in gl.diskList */
    mergediskListNodes();
}

/* pre: takes in a leaf* 'start' and a char* 'name', the data stored in the
 *      nodes of gl.fileSysfileSysTree must be of the type sysFile*
 * post: finds the the fileSysfileSysTree node in gl.fileSysfileSysTree that holds a sysFile* with the name
 *      'name' starting at the node 'start'
 * return: a leaf* that points to the node in gl.fileSysfileSysTree that holds an sysFile*
 *      with the name 'name', or NULL if such a node is not found
 */
leaf* findInHierarchy(leaf* start, char* name)
{
    leaf* ret;
    leaf* t; /* temp fileSysfileSysTree */
    node* n;
    node* neighbors; /* linked_list to hold the order for BFS */

    ret = NULL;
    neighbors = NULL;
    t = start;

    /* while node is not null and it's name doesn't match */
    while (t != NULL && strcmp(name, ((sysFile*)(t->data))->name))
    {
        if ((n = t->children) != NULL)
        {
            do /* add all children to the neighbors queue */
            {
                appendNode(&neighbors, createNode(n->data));
            } while ((n = n->next) != NULL);
        }

        if ((n = popNode(&neighbors)) != NULL)
        {
            /* TODO: might be leaking memory from popping off of neighbors */
            t = (leaf*)(n->data);
        }
        else
            t = NULL;
    }

    if (t != NULL)
        ret = t;

    return ret;
}

/* pre: takes in a sysFile* 'file' which must be either a valid file or
 *      directory
 * post: adds 'file' to the appropriate position in gl.fileSysfileSysTree, if the name of
 *      'file' contains 'PATH_SEP' then these are followed to add 'file' as a
 *      child of the appropriate fileSysfileSysTree node, else 'file' is added as a child of
 *      gl.currDir
 */
void addToHierarchy(sysFile* file)
{
    char* name;
    char* part;
    char delim[2];
    leaf* l; /* temp fileSysfileSysTree node */
    leaf** pd; /* temp fileSysfileSysTree node (parent dir) */
    int p; /* num path separations */

    pd = NULL;
    if (file != NULL)
    {
        delim[0] = PATH_SEP;
        delim[1] = '\0';
        name = strdup(file->name);

        if ((p = countPathSeparations(name)))
        {
            part = strtok(name, delim);
            if (part == NULL) /* this is meant to cover '/' as the root */
                part = delim;
            if ((l = findInHierarchy(gl.fileSysTree, part)) != NULL)
                pd = &l;
            while (p--)
            {
                part = strtok(NULL, delim);
                if (p > 0)
                    if ((l = findInHierarchy(gl.fileSysTree, part)) != NULL)
                        pd = &l;
            }

            if (pd == NULL || (*pd) == NULL)
            {
                fprintf(stderr, "%s: could not find directory\n", gl.exe);
                fflush(stderr);

                return;
            }
            else
            {

                /* we're making the file name shorter so strcpy should be fine */
                file->name = strcpy(file->name, part);

                /* TODO: possible memory leak? */
            }
        }
        else
        {
            if (gl.currDir != NULL)
                pd = &gl.currDir;
            else
                pd = &gl.fileSysTree;
        }


        free(name);

        /* append to the fileSysfileSysTree */
        appendLeaf(pd, createLeaf((void*)file));
    }
}

/* pre: takes in a char* 'fname' which is a file name
 * post: counts the number of occurances of the path separator 'PATH_SEP' in
 *      'fname'
 * return: an integer which is the number of occurances of 'PATH_SEP' in 'fname'
 */
int countPathSeparations(char* fname)
{
    int count;
    int i;

    count = 0;
    for (i = 0; i < strlen(fname); i++)
        if (fname[i] == PATH_SEP)
            count++;

    return count;
}

/* pre: takes in a sysFile* 'file'
 * post: build the full path name of 'file' from the gl.fileSysfileSysTree
 * return: a char* that is the full path name of 'file'
 */
char* getFullPath(sysFile* file)
{
    char* ret;
    char* parent;
    leaf* target;

    ret = (char*)malloc(1024*sizeof(char));
    target = findInHierarchy(gl.fileSysTree, file->name);

    if (target->parent != NULL)
    {
        /* TODO: probably leaking memory here */
        parent = getFullPath((sysFile*)target->parent->data);
        if (file->isDirectory)
        {
            sprintf(ret, "%s%s%c",
                    parent,
                    file->name,
                    PATH_SEP);
        }
        else
        {
            sprintf(ret, "%s%s",
                    parent,
                    file->name);
        }
    }
    else
    {
        if (file->isDirectory)
        {
            sprintf(ret, "%s%c",
                    file->name,
                    PATH_SEP);
        }
        else
        {
            sprintf(ret, "%s",
                    file->name);
        }
    }

    return ret;
}

