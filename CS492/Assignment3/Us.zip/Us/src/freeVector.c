#include "fs.h"

/* pre: takes in a char** 'vect'
 * post: frees each string in 'vect' then frees 'vect'
 */
void freeVector(char** vect)
{
	int i;

	for (i = 0; vect[i] != NULL; i++)
		free(vect[i]);
	free(vect[i]); /* free the last NULL */
	free(vect);
}

