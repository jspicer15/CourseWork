#include "fs.h"

/* pre: takes in a char* 'dir'
 * post: sets directory 'dir' as the current directory, or sets the parent
 *      directory as the current directory when 'dir' is '..'
 */
void fs_cd(char* dir)
{
    leaf* l;

    if (!strcmp(dir, ".."))
    {
        if ((l = gl.currDir->parent) != NULL)
            gl.currDir = l;
        else
        {
            printf("%s: cd: no such file or directory: %s\n", gl.exe, dir);
            fflush(stdout);
        }
    }
    else
    {
        if ((l = findInHierarchy(gl.currDir, dir)) != NULL)
            gl.currDir = l;
        else
        {
            printf("%s: cd: no such file or directory: %s\n", gl.exe, dir);
            fflush(stdout);
        }
    }
}

