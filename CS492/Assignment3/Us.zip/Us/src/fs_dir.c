#include "fs.h"

/* pre: none
 * post: prints out the directory fileSysfileSysTree in breadth-first order
 */
void direc()
{
    leaf* t; /* temp fileSysfileSysTree */
    node* n; /* temp node */
    sysFile* f; /* temp file */
    node* neighbors; /* linked_list to hold the order for BFS */

    neighbors = NULL;
    t = gl.fileSysfileSysTree;

    while (t != NULL)
    {
        f = (sysFile*)(t->data);
        printf("%s\n", getFullPath(f));
        fflush(stdout);

        if ((n = t->children) != NULL)
        {
            do /* add all children to the neighbors queue */
            {
                appendNode(&neighbors, createNode(n->data));
            } while ((n = n->next) != NULL);
        }

        if ((n = popNode(&neighbors)) != NULL)
        {
            /* TODO: might be leaking memory from popping off of neighbors */
            t = (leaf*)(n->data);
        }
        else
            t = NULL;
    }
}

