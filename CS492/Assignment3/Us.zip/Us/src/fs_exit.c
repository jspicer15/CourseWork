#include "fs.h"

/* pre: none
 * post: de-allocates data structures and exits the program
 */
void fs_exit()
{
    node* n;
    node* neighbors;
    sysFile* f;
    leaf* t;

    /* close open file descriptors */
    close(gl.fileList);
    close(gl.dirList);

    /* free gl.diskList */
    while ((n = popNode(&gl.diskList)) != NULL)
        free(n);

    /* free gl.fileSysfileSysTree */
    t = gl.fileSysTree;
    neighbors = NULL;
    while (t != NULL)
    {
        f = (sysFile*)(t->data);

        /* free the file */
        free(f->name);
        while ((n = popNode(&(f->lfile))) != NULL)
            free(n);
        free(f);

        if ((n = t->children) != NULL)
        {
            do
            {
                appendNode(&neighbors, createNode(n->data));
            } while ((n = n->next) != NULL);
        }

        /* free the fileSysfileSysTree node */
        free(t);

        if ((n = popNode(&neighbors)) != NULL)
        {
            /* TODO: might be leaking memory from popping off of neighbors */
            t = (leaf*)(n->data);
        }
        else
            t = NULL;
    }
}

