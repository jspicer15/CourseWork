#include "fs.h"

/* pre: takes in a char* 'name'
 * post: creates a new directory named 'name' in the current directory
 */
void fs_mkdir(char* name)
{
    /* only add if 'name' does not exist in the current directory */
    if (findInHierarchy(gl.currDir, name) != NULL)
    {
        printf("%s: mkdir: cannot create directory `%s`: File exists\n", gl.exe, name);
        fflush(stdout);
    }
    else
        addToHierarchy(createFile(name, 0, 1));
}

