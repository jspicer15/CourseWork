#include "fs.h"

/* pre: the flist file has been opened and it's file descriptor is in
 *      gl.fileList and the dir_list file has been opened and it's file
 *      descriptor is in gl.dirList
 * post: parses the flist and dlist files to initialize the global file
 *      hierarchy
 */
void init()
{
    ssize_t n;
    size_t s;
    char* line;
    char** vect;
    FILE* dir_stream;
    FILE* file_stream;
    sysFile* f; /* temp file */

    /* make sure gl.fileSysfileSysTree starts as NULL */
    gl.fileSysTree = NULL;

    /* initialize gl.currDir to NULL until after directories and files */
    gl.currDir = NULL;

    /* total number of blocks is disk size divided by block size */
    gl.blockNum = gl.diskSize / gl.blockSize;

    /* initialize gl.diskList to one node where all blocks are free */
    gl.diskList = NULL;
    appendNode(&gl.diskList, createNode((void*)createBlock(0, gl.blockNum, 1)));

    /* open streams on the file descriptors */
    if ((dir_stream = fdopen(gl.dirList, "r")) == NULL)
    {
        perror(gl.exe);

        exit(-1);
    }

    /* open streams on the file descriptors */
    if ((file_stream = fdopen(gl.fileList, "r")) == NULL)
    {
        perror(gl.exe);

        exit(-1);
    }

    line = NULL;
    s = 0;
    while ((n = getline(&line, &s, dir_stream)) != 0)
    {
        /* error check */
        if (n < 0 && !feof(dir_stream))
        {
            perror(gl.exe);

            exit(-1);
        }
        else if (feof(dir_stream))
            break;

        /* overwrite the newline character */
        line[n - 1] = '\0';

        /* create directories and add them to the fileSysfileSysTree */
        addToHierarchy(createFile(line, 0, 1));

        free(line);
        line = NULL;
        s = 0;
    }

    line = NULL;
    s = 0;
    while ((n = getline(&line, &s, file_stream)) != 0)
    {
        /* error check */
        if (n < 0 && !feof(file_stream))
        {
            perror(gl.exe);

            exit(-1);
        }
        else if (feof(file_stream))
            break;

        /* overwrite the newline character */
        line[n - 1] = '\0';

        /* break line up into a vector for easier parsing */
        vect = str2vect(line);

        /* create files and add them to the fileSysfileSysTree and disk */
        f = createFile(vect[10], atoi(vect[6]), 0);

        addToHierarchy(f);
        allocateFile(f);

        freeVector(vect);
        free(line);
        line = NULL;
        s = 0;
    }

    /* initialize gl.currDir to be the root of the fileSysfileSysTree */
    gl.currDir = gl.fileSysTree;
}

