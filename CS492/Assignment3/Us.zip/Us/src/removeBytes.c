#include "fs.h"

/* pre: takes in a char* 'file' and an int 'bytes'
 * post: removeBytess 'bytes' number of bytes from the file 'file'
 */
void removeBytes(char* file, int bytes)
{
    leaf* target;

    if (bytes < 0)
    {
        printf("usage: removeBytes name size\n");
        fflush(stdout);
    }
    else if ((target = findInHierarchy(gl.currDir, file)) != NULL)
    {
        /* only removeBytes from regular files */
        if (!(((sysFile*)(target->data))->isDirectory))
        {
            ((sysFile*)(target->data))->size -= bytes;
            /* TODO: actually de-allocate file */
            ((sysFile*)(target->data))->timestamp = time(NULL);
        }
    }
    else if (target == NULL)
    {
        printf("%s: removeBytes: no such file or directory: %s\n", gl.exe, file);
        fflush(stdout);
    }
}

