#include "fileSysTree.h"

/* pre: takes in a void* 'data'
 * post: allocates a new fileSysfileSysTree leaf that holds 'data'
 * return: a leaf* pointing to the newly allocated fileSysfileSysTree leaf, or NULL on error
 */
leaf* createLeaf(void* data)
{
    leaf* ret;

    ret = NULL;
    if (data != NULL)
    {
        if ((ret = (leaf*)malloc(sizeof(leaf))) != NULL)
        {
            ret->data = data;
            ret->parent = NULL;
            ret->children = NULL;
        }
    }

    return ret;
}

/* pre: takes in a leaf** 'fileSysfileSysTree' and a leaf* 'l'
 * post: appends 'l' to the fileSysfileSysTree as a child of 'fileSysfileSysTree'
 */
void appendLeaf(leaf** fileSysfileSysTree, leaf* l)
{
    if (l != NULL)
    {
        if ((*fileSysfileSysTree) == NULL)
            (*fileSysfileSysTree) = l;
        else
        {
            l->parent = (*fileSysfileSysTree);
            appendNode(&((*fileSysfileSysTree)->children), createNode((void*)l));
        }
    }
}

/* pre: takes in a leaf** 'fileSysfileSysTree' and a leaf* 'l'
 * post: removeBytess 'l' from the fileSysfileSysTree pointed to by 'fileSysfileSysTree'
 * return: a leaf* pointing to the leaf that was removeBytesd from 'fileSysfileSysTree', or NULL on
 *      error
 */
leaf* removeLeaf(leaf** fileSysfileSysTree, leaf* l)
{
    leaf* ret;
    node* n; /* temp node storage */
    node* neighbors; /* linked_list to hold the order for BFS */

    ret = NULL;
    if (l != NULL) /* if we're trying to removeBytes NULL skip everything */
    {
        if ((*fileSysfileSysTree) != NULL) /* if the fileSysfileSysTree we're removing from is NULL, skip */
        {
            if ((*fileSysfileSysTree) == l) /* if the root is what we're looking for */
            {
                ret = (*fileSysfileSysTree);
                fileSysfileSysTree = NULL;
            }
            else /* else check the children in BFS order */
            {
                /* make sure there are children */
                if ((n = (*fileSysfileSysTree)->children) != NULL)
                {
                    do /* add all children to queue */
                    {
                        appendNode(&neighbors, n);
                    } while ((n = n->next) != NULL);

                    /* pop the queue and check */
                    while ((n = popNode(&neighbors)) != NULL)
                    {
                        if (n->data == l)
                        {
                            ret = (leaf*)n->data;
                            break;
                        }
                        else if ((n = ((leaf*)(n->data))->children) != NULL)
                        {
                            do /* add all the children of this one to queue */
                            {
                                appendNode(&neighbors, n);
                            } while ((n = n->next) != NULL);
                        }
                    }
                }
            }
        }
    }

    return ret;
}

