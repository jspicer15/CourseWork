/*
  John Spicer
  CS546
*/

const printShapes = require('./printShapes');

/* TRIANGLE */
printShapes.triangle(1);
printShapes.triangle(2);
printShapes.triangle(3);
printShapes.triangle(4);
printShapes.triangle(5);
printShapes.triangle(6);
printShapes.triangle(7);
printShapes.triangle(8);
printShapes.triangle(9);
printShapes.triangle(10);
/* SQUARE */
printShapes.square(2);
printShapes.square(3);
printShapes.square(4);
printShapes.square(5);
printShapes.square(6);
printShapes.square(7);
printShapes.square(8);
printShapes.square(9);
printShapes.square(10);
printShapes.square(11);
/* RHOMBUS */
printShapes.rhombus(2);
printShapes.rhombus(4);
printShapes.rhombus(6);
printShapes.rhombus(8);
printShapes.rhombus(10);
printShapes.rhombus(12);
printShapes.rhombus(14);
printShapes.rhombus(16);
printShapes.rhombus(18);
printShapes.rhombus(20);
