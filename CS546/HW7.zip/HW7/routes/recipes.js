const express = require('express');
const router = express.Router();
const data = require("../data");
const recipeData = data.recipes;
const bodyParser = require('body-parser');

router.use(bodyParser.json());

router.get("/", (req, res) => {
    recipeData.getAllRecipes().then((recipes) => {
        res.json(recipes);
    }, () => {
        res.status(500).send();
    });
});

router.get("/:id", (req, res) => {
  recipeData.getRecipeById(req.params.id).then((recipe) => {
    res.json(recipe);
  }, (error) => {
    res.status(404).json({message: "ID Not Found"});
  });
});

router.post("/", (req, res) => {
  var recipe = req.body;
  if (!recipe) {
    res.status(400).json({error: "You must provide data for the recipe"});
    return;
  }

  if (!recipe.title) {
       res.status(400).json({ error: "You must provide a title for the id" });
       return;
   }

   if (!recipe.ingredients) {
       res.status(400).json({ error: "You must provide ingredients" });
       return;
   }

   if (!recipe.steps) {
     res.status(400).json({ error: "You must provide steps" });
     return;
   }

   recipeData.addRecipe(recipe.title, recipe.ingredients, recipe.steps)
       .then((newRecipe) => {
           res.json(newRecipe);
       }, () => {
           res.sendStatus(500);
       });
});


router.put("/:id", (req, res) => {
    var recipe = req.body;

    if (!recipe) {
        res.status(400).json({ error: "You must provide data to update a recipe" });
        return;
    }

    if (!recipe.title) {
         res.status(400).json({ error: "You must provide a title for the id" });
         return;
     }

     if (!recipe.ingredients) {
         res.status(400).json({ error: "You must provide ingredients" });
         return;
     }

     if (!recipe.steps) {
       res.status(400).json({ error: "You must provide steps" });
       return;
     }

    var getRecipe = recipeData.getRecipeById(req.params.id).then(() => {
        return recipeData.updateRecipe(req.params.id, recipe)
            .then((updatedRecipe) => {
                res.json(updatedRecipe);
            }, (error) => {
                console.log(error);
                res.sendStatus(500);
            });
    }).catch(() => {
        res.status(404).json({ error: "Recipe not found" });
    });

});


router.delete("/:id", (req, res) => {
    var recipe = recipeData.getRecipeById(req.params.id).then(() => {
        return recipeData.removeRecipe(req.params.id)
            .then(() => {
                res.sendStatus(200);
            }).catch(() => {
                res.sendStatus(500);
            });

    }).catch((err) => {
        console.log(err);
        res.status(404).json({ error: "Recipe not found" });
    });
});

module.exports = router;
