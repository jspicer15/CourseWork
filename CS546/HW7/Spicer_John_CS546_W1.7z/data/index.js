const commentData = require("./comments");
const recipeData = require("./recipes");

module.exports = {
    comments: commentData,
    recipes: recipeData
};
