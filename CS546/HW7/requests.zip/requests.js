var request = require('request');
var jsonRecipe = {
title: "Fried Eggs",
ingredients: [
{
  name: "Egg",
  amount: "2 eggs"
},
{
  name: "Olive Oil",
  amount: "2 tbsp"
},
],
steps: [
"First, heat a non-stick pan on medium-high until hot",
"Add the oil to the pan and allow oil to warm; it is ready the oil immediately sizzles upon contact with a drop of water.",
"Crack the egg and place the egg and yolk in a small prep bowl; do not crack the yolk!",
"Gently pour the egg from the bowl onto the oil",
"Wait for egg white to turn bubbly and completely opaque (approx 2 min)",
"Using a spatula, flip the egg onto its uncooked side until it is completely cooked (approx 2 min)",
"Remove from oil and plate",
"Repeat for second egg"
],
comments: []
};
var jsonComment = {
  poster: "Jeffrey Ramsay",
  comment: "These eggs are delicious!"
}
request({
    url: "http://localhost:3000/comments/8934b9a5-e5b2-4d7f-9078-a65aab60cd62",
    method: "DELETE",
    json: true,   // <--Very important!!!
    body: jsonComment
}, function (error, response, body){
    console.log(response);
});
