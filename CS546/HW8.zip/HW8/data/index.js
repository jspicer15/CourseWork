const mainRoute = require("./main");
let constructorMethod = (app) => {
    app.use("/", mainRoute);
};
module.exports = {
    terms: require("./terms")
, };