const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const data = require("../data");
const termData = data.terms;
router.use(bodyParser.urlencoded({
    extended: true
}));

function checkPalindrome(word) {
    if (typeof word !== 'string') {
        throw "the word must be a string";
    }
    else {
        if (word === word.split('').reverse().join('')) {
            console.log("yay");
            return true;
        }
        else {
            console.log("o no");
            return false;
        }
    }
}
router.get("/", (req, res) => {
    try {
        termData.getAllPosts().then((termList) => {
            res.render('layouts/main', {
                terms: termList
            });
        });
    }
    catch (err) {
        res.status(500).send('Server Error:' + err);
    }
});
router.post("/", (req, res) => {
    var postData = req.body;
    try {
        if (checkPalindrome(req.body.textInput)) {
            termData.newTerm(postData, true).then(() => {
                return;
            });
        }
        else {
            termData.newTerm(postData, false).then(() => {
                return;
            });
        }
        res.redirect("/");
    }
    catch (err) {
        res.status(500).semd('Server Error:' + err);
    }
})
module.exports = router;